<?php
require_once (dirname(__DIR__) . '/ecmessage.class.php');
class ecMessage_mysql extends ecMessage {}