<?php
require_once (dirname(__DIR__) . '/ecthread.class.php');
class ecThread_mysql extends ecThread {}