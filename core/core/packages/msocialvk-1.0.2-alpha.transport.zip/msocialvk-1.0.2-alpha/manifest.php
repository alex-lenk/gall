<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f8c1d7dfc50e2400581d03ca5a51830',
      'native_key' => 'msocial_vk_tp',
      'filename' => 'modSystemSetting/d6807732e73361d2798f9f3c16b6b1ec.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1524b01a590cd75f8c0fb56ec44099b',
      'native_key' => 'msocial_vk_id',
      'filename' => 'modSystemSetting/6ddeb8d357fab7f5dc7a9c0ef5178e8b.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d21ce1da62a82b57fd95319f5db71b3',
      'native_key' => 'msocial_vk_at',
      'filename' => 'modSystemSetting/74566d95bab3be25f235a5e47c241abf.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e54d9d81705f62f2b05857323870a13c',
      'native_key' => 'msocial_im_fg',
      'filename' => 'modSystemSetting/a377c594b5bb4e9d4882e6d0b54baf47.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6c2c5e603bfd30771a76e5bff0bcb798',
      'native_key' => 45,
      'filename' => 'modCategory/fa81d1a4315ba7f3960b918480a856e5.vehicle',
    ),
  ),
);