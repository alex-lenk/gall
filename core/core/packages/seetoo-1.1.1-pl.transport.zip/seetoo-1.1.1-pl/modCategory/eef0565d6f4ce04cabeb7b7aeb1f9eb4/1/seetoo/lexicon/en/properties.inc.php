<?php

$_lang['see_prop_cache'] = 'Caching the results of the snippet.';
$_lang['see_prop_cacheTime'] = 'Time until the cache expires, in seconds.';
$_lang['see_prop_element'] = 'Name of snippet, which to be call for taking results.';
$_lang['see_prop_parents'] = 'Comma-delimited list of ids serving as parents. Use "0" to ignore parents when specifying resources to include. Prefix an id of parent with a dash to exclude it and its children from the result.';
$_lang['see_prop_showUnactive'] = 'If true, will also show Resources regardless if they are unactive.';
$_lang['see_prop_useRandom'] = 'If false, snippet will not return random resources';
$_lang['see_prop_views'] = 'Number of passages, in which the resource enters the results of the snippet.';
$_lang['see_prop_filter'] = 'Type of relation. Default "view"';
