<?php
class SeeTooResource extends xPDOSimpleObject {}