<?php

$_lang['area_seetoo_main'] = 'Main';

$_lang['setting_seetoo_exclude_content_type'] = 'Exclude resource by mime type';
$_lang['setting_seetoo_exclude_where'] = 'Exclude resource from json';
$_lang['setting_seetoo_excluder_class'] = 'Class for exclude resources';