<?php

$_lang['area_seetoo_main'] = 'Основные';

$_lang['setting_seetoo_exclude_content_type'] = 'Список MIME типов, которые нужно исключить';
$_lang['setting_seetoo_exclude_where'] = 'JSON строка для исключения ресурсов. Например {"is_folder":"1","parent":"2"}';
$_lang['setting_seetoo_excluder_class'] = 'Класс, которых содержит логику для исключения ресурсов из связи';