<?php

class modResourceGetProcessor extends modObjectGetProcessor {
    public $classKey = 'modResource';
    public $languageTopics = array('seetoo:default');

}

return 'modResourceGetProcessor';