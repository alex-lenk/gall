--------------------
SeeToo
--------------------
Author: Vladimir Kisilitsa <vkisilica@gmail.com>
--------------------

"SeeToo" component for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/redcore7/SeeToo/issues