<?php
require_once (dirname(dirname(__FILE__)) . '/seetooresource.class.php');
class SeeTooResource_mysql extends SeeTooResource {}