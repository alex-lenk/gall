<?php

$_lang['mapex2_prop_map'] = 'json строка с картой';
$_lang['mapex2_prop_tvName'] = 'Имя TV параметра с картой';
$_lang['mapex2_prop_resource'] = 'Страница с картой';
$_lang['mapex2_prop_mapId'] = 'Id карты';
$_lang['mapex2_prop_width'] = 'Ширина карты';
$_lang['mapex2_prop_height'] = 'Высота карты';
$_lang['mapex2_prop_containerCssClass'] = 'Css класс контейнера с картой';
$_lang['mapex2_prop_mapTpl'] = 'Чанк для карты';
$_lang['mapex2_prop_placemarkTpl'] = 'Чанк для точки';
$_lang['mapex2_prop_polygonTpl'] = 'Чанк для фигуры';
$_lang['mapex2_prop_polylineTpl'] = 'Чанк для линии';
$_lang['mapex2_prop_routeTpl'] = 'Чанк для маршрута';
$_lang['mapex2_prop_controls'] = 'Набор элементов управления для карты';
$_lang['mapex2_prop_includeJs'] = 'Добавить на страницу подключение JS файла яндекс карт';
