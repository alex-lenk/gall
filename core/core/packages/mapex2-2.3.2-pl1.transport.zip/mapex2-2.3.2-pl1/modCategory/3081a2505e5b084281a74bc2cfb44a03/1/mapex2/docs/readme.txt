--------------------
mapex2
--------------------
Author: Naumov Alexey <info@createit.ru>
--------------------

A custom TV output render type that allows you to output a TV value into a Yandex Map. Supports points, polylines, polygones, routes.