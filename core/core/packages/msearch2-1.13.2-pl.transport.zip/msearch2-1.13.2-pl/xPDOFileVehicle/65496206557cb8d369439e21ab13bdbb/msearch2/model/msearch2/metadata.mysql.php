<?php

$xpdo_meta_map = array (
  'xPDOObject' => 
  array (
    0 => 'mseWord',
    1 => 'mseIntro',
    2 => 'mseQuery',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'mseAlias',
  ),
);