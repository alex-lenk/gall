<?php
require_once (dirname(__DIR__) . '/ecreplytemplate.class.php');
class ecReplyTemplate_mysql extends ecReplyTemplate {}