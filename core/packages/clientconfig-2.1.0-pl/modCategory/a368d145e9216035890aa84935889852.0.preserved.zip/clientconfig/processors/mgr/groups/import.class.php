<?php
require_once dirname(dirname(__FILE__)) . '/import.class.php';
/**
 * Class cgGroupImportProcessor
 */
class cgGroupImportProcessor extends ClientConfigImportProcessor
{
    public $classKey = 'cgGroup';
}

return 'cgGroupImportProcessor';
