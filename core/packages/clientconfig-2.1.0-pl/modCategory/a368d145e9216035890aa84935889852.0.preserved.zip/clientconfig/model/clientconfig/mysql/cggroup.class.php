<?php
require_once (dirname(dirname(__FILE__)) . '/cggroup.class.php');
class cgGroup_mysql extends cgGroup {}