<?php
include_once 'setting.inc.php';

$_lang['simpleupdater'] = 'MODX Updater';
$_lang['simpleupdater_menu_desc'] = 'Update MODX version';
$_lang['simpleupdater_update'] = 'Update MODX';
$_lang['simpleupdater_intro_msg'] = 'Update MODX version';
$_lang['simpleupdater_update_start'] = 'Start updating';
