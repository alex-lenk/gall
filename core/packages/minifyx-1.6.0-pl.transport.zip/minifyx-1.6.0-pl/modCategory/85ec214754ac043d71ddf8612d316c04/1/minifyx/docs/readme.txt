--------------------
MinifyX
--------------------

MinifyX is a MODX® Revolution addon that allows you to combine and minify JS and CSS files to speed up your site and reduce server load.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/sergant210/MinifyX/issues