<?php
return str_replace(array(' ','-','(',')'), '', strip_tags($input));